# import asyncio
# import datetime
# import os
# from selenium import webdriver
# from selenium.webdriver.chrome.options import Options
# from selenium.webdriver.common.by import By
# from selenium.webdriver.common.keys import Keys
# from selenium.webdriver.support.ui import WebDriverWait
# from selenium.webdriver.support import expected_conditions as EC
# from concurrent.futures import ThreadPoolExecutor, as_completed
# from langchain_community.document_loaders import BSHTMLLoader
# from pydantic import BaseModel
#
#
# class SearchResult(BaseModel):
#     title_and_links: list = []
#     google_top_response: str = ""
#     html_content: str = ""
#     urls: list = []
#
#
# class GoogleSearcher:
#     def __init__(self, chromedriver_path="/usr/local/bin/chromedriver"):
#         self.chromedriver_path = chromedriver_path
#
#     def _setup_driver(self):
#         chrome_options = Options()
#         # chrome_options.add_argument("--headless")
#         chrome_options.add_argument("--disable-gpu")
#         chrome_options.add_argument("--no-sandbox")
#         chrome_options.add_argument("--disable-dev-shm-usage")
#         chrome_options.add_argument("--disable-extensions")
#         chrome_options.add_argument("--disable-images")
#         chrome_options.add_argument("--blink-settings=imagesEnabled=false")
#         chrome_options.add_argument("--start-maximized")
#         chrome_options.page_load_strategy = 'eager'
#
#         return webdriver.Chrome(self.chromedriver_path, options=chrome_options)
#
#     async def __get_google_top_result(self, driver):
#         html_content = driver.page_source
#         name = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
#         with open(f"{name}.txt", "w", encoding="utf-8") as f:
#             f.write(html_content)
#         data = BSHTMLLoader(f"{name}.txt"
#                             ).load()
#         data = "".join(data[0].page_content.split("\n")[1:6])
#         os.remove(f"{name}.txt")
#         return data, html_content
#
#     async def search(self, query, num_results=10, filename="search_result_html.txt",
#                      search_provider = "google") -> SearchResult:
#         driver = self._setup_driver()
#         try:
#             driver.get(f"https://www.{search_provider}.com")
#
#             search_box = driver.find_element(By.NAME, "q")
#             search_box.send_keys(query)
#             search_box.send_keys(Keys.RETURN)
#
#             await asyncio.sleep(5)  # Wait for page to load
#
#             WebDriverWait(driver, 5).until(
#                 EC.presence_of_element_located((By.ID, "search"))
#             )
#
#             results = driver.find_elements(By.CSS_SELECTOR, "div.g")
#             search_results = []
#             for result in results[:num_results]:  # Limit to first 10 results for speed
#                 try:
#                     title = result.find_element(By.CSS_SELECTOR, "h3").text
#                     link = result.find_element(By.CSS_SELECTOR, "a").get_attribute("href")
#                     search_results.append({"title": title, "link": link})
#                 except:
#                     continue
#             google_response, html_content = await self.__get_google_top_result(driver)
#             urls = [x['link'] for x in search_results]
#
#             return SearchResult(title_and_links=search_results,
#                                 google_top_response=google_response,
#                                 html_content=html_content,
#                                 urls=urls)
#         except:
#             return SearchResult(title_and_links=[],
#                                 google_top_response="",
#                                 html_content="",
#                                 urls=[])
#         finally:
#             driver.quit()


import asyncio
import datetime
import logging
import os
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from concurrent.futures import ThreadPoolExecutor, as_completed
from langchain_community.document_loaders import BSHTMLLoader
from pydantic import BaseModel

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class SearchResult(BaseModel):
    title_and_links: list = []
    top_response: str = ""
    html_content: str = ""
    urls: list = []


class GoogleSearcher:
    def __init__(self, chromedriver_path="/usr/local/bin/chromedriver"):
        self.chromedriver_path = chromedriver_path

    def _setup_driver(self):
        chrome_options = Options()
        chrome_options.add_argument("--headless")
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--disable-extensions")
        chrome_options.add_argument("--disable-images")
        chrome_options.add_argument("--blink-settings=imagesEnabled=false")
        chrome_options.add_argument("--start-maximized")
        chrome_options.page_load_strategy = 'eager'

        return webdriver.Chrome(self.chromedriver_path, options=chrome_options)

    async def __get_top_result(self, driver, search_provider):
        html_content = driver.page_source
        name = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        with open(f"{name}.txt", "w", encoding="utf-8") as f:
            f.write(html_content)
        data = BSHTMLLoader(f"{name}.txt").load()

        if search_provider == "google":
            data = "".join(data[0].page_content.split("\n")[1:6])
        elif search_provider == "bing":
            # Adjust this based on Bing's structure
            data = "".join(data[0].page_content.split("\n")[1:6])

        os.remove(f"{name}.txt")
        return data, html_content

    async def search(self, query, num_results=10, filename="search_result_html.txt",
                     search_provider="google") -> SearchResult:
        logger.info("Starting Chromedrive ...")
        driver = self._setup_driver()
        try:
            if search_provider == "google":
                driver.get("https://www.google.com")
                search_box = WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.NAME, "q"))
                )
            elif search_provider == "bing":
                driver.get("https://www.bing.com")
                search_box = WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.ID, "sb_form_q"))
                )
            else:
                raise ValueError("Unsupported search provider")

            # Use JavaScript to set the value and submit the form
            driver.execute_script(f"arguments[0].value = '{query}';", search_box)
            driver.execute_script("arguments[0].form.submit();", search_box)

            # Wait for the results page to load
            if search_provider == "google":
                WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.ID, "search"))
                )
                results = driver.find_elements(By.CSS_SELECTOR, "div.g")
            elif search_provider == "bing":
                WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.ID, "b_results"))
                )
                results = driver.find_elements(By.CSS_SELECTOR, "li.b_algo")

            # Process search results
            search_results = []
            logger.info(f"Results Length: {len(results)}")
            for result in results[:num_results]:
                try:
                    if search_provider == "google":
                        title = result.find_element(By.CSS_SELECTOR, "h3").text
                        link = result.find_element(By.CSS_SELECTOR, "a").get_attribute("href")
                    elif search_provider == "bing":
                        title = result.find_element(By.CSS_SELECTOR, "h2").text
                        link = result.find_element(By.CSS_SELECTOR, "h2 a").get_attribute("href")
                    search_results.append({"title": title, "link": link})
                except Exception as e:
                    print(f"Error parsing result: {str(e)}")
                    continue

            top_response, html_content = await self.__get_top_result(driver, search_provider)
            urls = [x['link'] for x in search_results]
            logger.info("Chromedriver closed")
            return SearchResult(title_and_links=search_results,
                                top_response=top_response,
                                html_content=html_content,
                                urls=urls)
        except Exception as e:
            print(f"An error occurred: {str(e)}")
            return SearchResult(title_and_links=[],
                                top_response="",
                                html_content="",
                                urls=[])
        finally:
            driver.quit()