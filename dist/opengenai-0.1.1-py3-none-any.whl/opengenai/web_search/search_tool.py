import asyncio
import logging

from .html_parser import FastHTMLParser, FastHTMLParserV2, FastHTMLParserV3
from .embed_search import fast_embedding_search
from .search import GoogleSearcher

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class WebFetcher:
    @staticmethod
    async def fetch(query, top_k=5, fast_response=False,
                    chromedriver_path="/usr/local/bin/chromedriver",
                    max_length=None, summarize=False, summary_sentences=3,
                    search_provider = "google",
                    num_results = 10,
                    url_fetch_timeout=10, extract_url_content=False):
        searcher = GoogleSearcher(chromedriver_path=chromedriver_path)
        res = await searcher.search(query=query,
                                    search_provider = search_provider,
                                    num_results=num_results)
        logger.info(f"Urls : {res.urls}")
        if extract_url_content:
            parser = FastHTMLParserV3(urls=res.urls, fast_response=fast_response,
                                      max_length=max_length, summarize=summarize, summary_sentences=summary_sentences)
            contents = await parser.fetch_content(url_fetch_timeout=url_fetch_timeout)
            text_corpus: str = "\n".join(contents)
            if not text_corpus.strip():
                return "No valid content found for the given query.", res
            results = fast_embedding_search(text_corpus, query, top_k=top_k)
            response_str = "\n".join([s for s, _ in results])
        else:
            response_str = ""
        return response_str,res

# class WebFetcher:
#     @staticmethod
#     def google_fetch(query, top_k=3, fast_response=False):
#         async def async_fetch():
#             searcher = GoogleSearcher()
#             res = searcher.search(query=query)
#             parser = FastHTMLParserV3(urls=res.urls, fast_response=fast_response)
#             contents = await parser.fetch_content()
#             text_corpus: str = "\n".join(contents)
#             results = fast_embedding_search(text_corpus, query, top_k=top_k)
#             response_str = "\n".join([s for s, _ in results])
#             return response_str
#
#         return asyncio.run(async_fetch())
